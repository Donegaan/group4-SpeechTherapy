package com.example.sweng04.speachtherapyapp.OmRecorder;

interface ThreadAction {

    /**
     * Execute {@code runnable} action on implementer {@code Thread}
     */
    void execute(Runnable action);
}
